package com.cc.zuoye.zuoye3.question1.lab7_1.observer;

/**
 * @author shubing
 */
public interface Observer {
    void show();
}
